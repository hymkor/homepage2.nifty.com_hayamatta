/* ntconsole.cpp
 *   �R���\�[���𒼐ڑ��삷��֐��Ȃǂ��i�[����B
 */

#if !defined(__DMC__) && !defined(__OS2__)
#  include <conio.h>
#endif
#include <stdio.h>
#include <dos.h>
#include "config.h"
#include "ntconsole.h"
#include "writer.h"

#if defined(OS2EMX) /*** OS/2 ��p static �ϐ�/�֐��Q ***/

#include <stdlib.h>
#define INCL_WIN
#define INCL_VIO
#define INCL_DOSPROCESS
#include <os2.h> 

static HAB hab,hmq;

static int init_os2()
{
    static int first=1;
    if( first ){
	first = 0;

	PTIB  ptib = NULL;
	PPIB  ppib = NULL;
	APIRET rc = DosGetInfoBlocks(&ptib, &ppib);
	if (rc != 0)
	    return rc;
	ppib->pib_ultype = PROG_PM;
	hab = WinInitialize(0);
	hmq = WinCreateMsgQueue(hab, 0);
	if (hmq == NULLHANDLE)
	    return rc;
    }
    return 0;
}

#elif defined(NYACUS) /*** Borland C++/VC++ ��p static �ϐ�/�֐��Q ***/

#include <windows.h>

static HANDLE   hStdin = (HANDLE )-1L;
static HANDLE   hStdout = (HANDLE )-1L;

/* API�ɂ��W�����o�͂̏����� */
static void initializeStdio()
{
    hStdin  = GetStdHandle(STD_INPUT_HANDLE);   /* �W�����̓n���h���̎擾 */
    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);  /* �W���o�̓n���h���̎擾 */
}

static void locate(int x,int y)
{
    COORD coord;
    if( hStdout == (HANDLE )-1L )
	initializeStdio();

    coord.X = x ; coord.Y = y;
    SetConsoleCursorPosition(hStdout,coord);
}
static void getLocate(int &x,int &y)
{
    if (hStdout == (HANDLE )-1L)
	initializeStdio();

    CONSOLE_SCREEN_BUFFER_INFO  csbi;
    if (GetConsoleScreenBufferInfo(hStdout,&csbi) == FALSE)
	return;
    
    x = csbi.dwCursorPosition.X;
    y = csbi.dwCursorPosition.Y;
}
#else /***** DOS �p static �֐�/�ϐ��Q ****/
static NnString tinyClipBoard;
#endif

/* �R���\�[���̃N���A */
void  Console::clear()
{
#ifdef __BORLANDC__
    static COORD                coordScreen;
    DWORD                       dwCharsWritten;
    DWORD                       dwConsoleSize;
    CONSOLE_SCREEN_BUFFER_INFO  csbi;

    if (hStdout == (HANDLE )-1L)
	initializeStdio();

    /* �R���\�[���̃L�����N�^�o�b�t�@�����擾 */
    if(GetConsoleScreenBufferInfo(hStdout,&csbi) == FALSE)
	initializeStdio();

    /* �L�����N�^�o�b�t�@�T�C�Y���v�Z */
    dwConsoleSize = csbi.dwSize.X * csbi.dwSize.Y;

    /* �L�����N�^�o�b�t�@���󔒂Ŗ��߂� */
    FillConsoleOutputCharacter(
        hStdout,' ',dwConsoleSize,coordScreen,&dwCharsWritten);

    /* ���݂̃e�L�X�g�����̎擾 */
    if (GetConsoleScreenBufferInfo(hStdout,&csbi) == FALSE)
        return;

    /* ���ׂĂ̕����ɑ΂��Ď擾�����e�L�X�g������K�p���� */
    FillConsoleOutputAttribute(
        hStdout,csbi.wAttributes,dwConsoleSize,coordScreen,&dwCharsWritten);

    /* �J�[�\���ʒu������p�Ɉړ� */
    SetConsoleCursorPosition(hStdout,coordScreen);
#else
    fputs("\x1B[2J",stdout);
#endif
}

void Console::backspace(int n)
{
    if( n <= 0 )
	return;

#ifdef ESCAPE_SEQUENCE_OK
    conOut << "\x1B[" << (int)n << 'D';
#elif defined(__BORLANDC__)
    int x,y;
    getLocate(x,y);
    locate(x-n,y);
#else
    while( n-- > 0 )
	putchar('\b');
#endif
}

#if 0
void Console::keep_bottom_line()
{
    int x,y1,y2;

    getLocate(x,y1);
    putchar('\n');
    fflush(stdout);
    getLocate(x,y2);

    if( y1 == y2 )
        locate(x,y1);
    else
	locate(x,y1-1);
}
#endif

int Console::getkey()
{
#ifdef __DMC__
#ifdef ASM_OK
    _asm {
	mov ah,07h
	int 21h
	xor ah,ah
    }
#else
    union REGS in,out;
    in.h.ah = 0x7;
    int86( 0x21 , &in , &out );
    return out.h.al & 255;
#endif
#else
    return getch() & 255;
#endif
}

#ifdef NYACUS
void Console::cursorOn()
{
    int x,y;
    getLocate(x,y);locate(x,y);
}
#endif

void Console::writeClipBoard( const char *ptr , int size )
{
#ifdef NYACUS
    HGLOBAL hText = GlobalAlloc(GMEM_DDESHARE | GMEM_MOVEABLE, size+1 );
    char *pText = (char*)GlobalLock(hText);
    if( pText != NULL ){
        memcpy( pText , ptr , size );
        pText[ size ] = '\0';
        GlobalUnlock(hText);

        OpenClipboard(NULL);
        EmptyClipboard();
        SetClipboardData(CF_TEXT, hText);
        CloseClipboard();
    }
#elif defined(NYAOS2)
    char *pText = NULL;
    DosAllocSharedMem( (void**)(&pText)
			, NULL
			, (ULONG)size+1
			, PAG_COMMIT | PAG_READ | PAG_WRITE
			| OBJ_TILE   | OBJ_GIVEABLE );
    if( pText != NULL ){
        memcpy( pText , ptr , size );
        pText[ size ] = '\0';
	init_os2();
	WinOpenClipbrd(hab);
	WinSetClipbrdOwner(hab,NULLHANDLE);
	WinEmptyClipbrd(hab);
	WinSetClipbrdData( hab, (ULONG)pText, CF_TEXT, CFI_POINTER );
	WinCloseClipbrd(hab);
    }
#else
    tinyClipBoard.assign(ptr,size);
#endif
}

void Console::readClipBoard( NnString &buffer )
{
#ifdef NYACUS
    buffer.erase();
    ::OpenClipboard(NULL);
    HANDLE hText=::GetClipboardData(CF_TEXT);
    if( hText != NULL ){
        char *pText = (char*)::GlobalLock(hText);
        if( pText != NULL ){
	    buffer = pText;
            ::GlobalUnlock(hText);
        }
    }
    ::CloseClipboard();
#elif defined(NYAOS2)
    init_os2();
    WinOpenClipbrd(hab);
    WinSetClipbrdOwner(hab,NULLHANDLE);
    ULONG ulFmtInfo;
    if( WinQueryClipbrdFmtInfo( hab, CF_TEXT, &ulFmtInfo ) ){
	char *text = (char*)WinQueryClipbrdData( hab, CF_TEXT );
	if( text != NULL )
	    buffer = text;
    }
    WinCloseClipbrd(hab);
#else
    buffer = tinyClipBoard;
#endif
}
