#ifndef LFN_H
#define LFN_H

#if defined(__DMC__) && defined(__OS2__)
#  include <sys/dirent.h>
#endif

#include "config.h"
#include "nnstring.h"
#include "nnstrhash.h"

#ifdef NYADOS
    union  REGS;
    struct SREGS;
#endif

class NnDir : public NnEnum {
    int 	status , hasHandle;
    unsigned	handle , attr_ ;
    NnString    name_;
#ifdef NYADOS
    unsigned findcore( union REGS &in , union REGS &out , struct SREGS &segs );
#endif
    unsigned findfirst( const NnString &path , unsigned attr );
    unsigned findfirst( const char *path     , unsigned attr );
    unsigned findnext ( );
    void findclose();
public:
    NnDir( const NnString &path , int attr=0x37 )
	{ status = NnDir::findfirst( path , attr ); }
    NnDir( const char *path , int attr=0x37 )
	{ status = NnDir::findfirst( path , attr ); }
    NnDir()
        { status = NnDir::findfirst( "." , 0x37 ); }
    ~NnDir();
    virtual NnObject *operator *();
    virtual void      operator++(void);
    NnString *operator ->(){ return &name_; }
    const char *name() const { return name_.chars() ; }
    int isReadOnly() const { return (attr_ & 0x01) != 0 ; }
    int isHidden()   const { return (attr_ & 0x02) != 0 ; }
    int isSystem()   const { return (attr_ & 0x04) != 0 ; }
    int isLabel()    const { return (attr_ & 0x08) != 0 ; }
    int isDir()      const { return (attr_ & 0x10) != 0 ; }
    int isArchived() const { return (attr_ & 0x20) != 0 ; }

    // �e�� VFAT �p�c�[���W.
    static void f2b( const char * , NnString & );
    static void filter( const char * , NnString & );
    static int  getcwd( NnString &pwd );
    static int  getcwdrive();
    static int  chdrive( int driveletter );
    static int  chdir( const char *dirname );
    static int  open( const char *fname , const char *mode );
    static int  write( int fd , const void *ptr , size_t size );
    static void close( int fd );
    static const NnString &tempfn();
    static int access( const char *path );
    static int lastRoot(const char *path)
	{ return NnString::findLastOf(path,"/\\:"); }
    static int seekEnd( int handle );
#ifdef NYADOS
    static const char *long2short( const char *src );
#else
    static const char *long2short( const char *src ){ return src; }
#endif
    static void extractDots( const char *&sp, NnString &dst );
    static NnStrHash specialFolder;
};

#endif

