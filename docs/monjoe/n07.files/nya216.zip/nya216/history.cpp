#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "nnstring.h"
#include "nnvector.h"
#include "history.h"
#include "reader.h"
#include "shell.h"

/* �q�X�g���̒�����A���蕶������܂񂾍s�����o��
 *	key - �����L�[
 *	line - �q�b�g�����s
 * return 0 - �������� , -1 - ������Ȃ�����.
 */
int History::seekLineHas( const NnString &key , NnString &line )
{
    NnString temp;
    for( int j=size()-2 ; j >= 0 ; --j ){
	this->get( j , temp );
	if( strstr(temp.chars(),key.chars()) != NULL ){
	    line = temp;
	    return 0;
	}
    }
    return -1;
}
/* �q�X�g���̒�����A���蕶���񂩂�n�܂����s�����o��
 *	key - �����L�[
 *	line - �q�b�g�����s
 * return 0 - �������� , -1 - ������Ȃ�����.
 */
int History::seekLineStartsWith( const NnString &key , NnString &line )
{
    NnString temp;
    for( int j=size()-2 ; j >= 0 ; --j ){
	this->get( j , temp );
	if( strncmp(temp.chars(),key.chars(),key.length())==0 ){
	    line = temp;
	    return 0;
	}
    }
    return -1;
}

/* �����񂩂�q�X�g���L�������o���āA�u�����s���B
 *      hisObj - �q�X�g���I�u�W�F�N�g
 *      src - ��������
 *      dst - �u�����ʂ������ or �G���[������
 * return
 *	0 - ����I�� , -1 - �G���[
 */
int preprocessHistory( History &hisObj , const NnString &src , NnString &dst )
{
    NnString line;
    int quote=0;
    const char *sp=src.chars();

    while( *sp != '\0' ){
	if( *sp != '!' || quote ){
            if( *sp == '"' )
                quote = !quote;
            dst += *sp++;
        }else{
            NnVector argv;
            NnString *arg1;

	    if( *++sp == '\0' )
                break;
            
            int sign=0;
            switch( *sp ){
            case '!':
                ++sp;
            case '*':case ':':case '$':case '^':
		if( hisObj.size() >= 2 ){
		    hisObj.get(-2,line);
                }else{
                    line = "";
		}
                break;
            case '-':
                sign = -1;
		++sp;
            default:
                if( isDigit(*sp) ){
		    int number = (int)strtol(sp,(char**)&sp,10);
		    hisObj.get( sign ? -number-1 : +number , line );
                }else if( *sp == '?' ){
                    NnString key,temp;
                    while( *sp != '\0' ){
                        if( *sp == '?' ){
			    ++sp;
                            break;
                        }
                        key += *sp;
                    }
		    if( hisObj.seekLineHas(key,line) != 0 ){
			dst.erase();
			dst << "!?" << key << ": event not found.\n";
			return -1;
		    }
                }else{
                    NnString key;
		    NyadosShell::readWord(sp,key);

		    if( hisObj.seekLineStartsWith(key,line) != 0 ){
			dst.erase();
			dst << "!" << key << ": event not found.\n";
			return -1;
		    }
                }
                break;
            }
	    line.splitTo( argv );

            if( *sp == ':' )
                ++sp;

            switch( *sp ){
            case '^':
                if( argv.size() > 1 && (arg1=(NnString*)argv.at(1)) != NULL )
                    dst += *arg1;
		++sp;
                break;
            case '$':
                if( argv.size() > 0 
                    && (arg1=(NnString*)argv.at(argv.size()-1)) != NULL )
                    dst += *arg1;
		++sp;
                break;
            case '*':
                for(int j=1;j<argv.size();j++){
                    arg1 = (NnString*)argv.at( j );
                    if( arg1 != NULL )
                        dst += *arg1;
                    dst += ' ';
                }
		++sp;
                break;
            default:
                if( isDigit(*sp) ){
		    int n=strtol(sp,(char**)&sp,10);
                    if( argv.size() >= n && (arg1=(NnString*)argv.at(n)) != NULL )
                        dst += *arg1;
                }else{
                    dst += line;
                }
                break;
            }
        }
    }
    return 0;
}

NnString *History::operator[](int at)
{
    if( at >= history.size() )
	NULL;
    if( at >= 0 )
        return (NnString *)history.at(at);
    at += history.size();
    if( at < 0 || at >= history.size() )
	return NULL;
    return (NnString *)history.at( at );
}
int History::size()
{
    return history.size();
}

void History::pack()
{
    NnString *r1=(*this)[-1];
    NnString *r2=(*this)[-2];
    if( size() >= 2 && r1 != NULL && r2 != NULL && r1->compare( *r2 ) == 0 )
	delete history.pop();
}

History &History::operator << ( const NnString &str )
{
    history.append( str.clone() );
    return *this;
}

void History::read( Reader &reader )
{
    NnString buffer;
    while( reader.readLine(buffer) >= 0 ){
	history.append( buffer.clone() );
    }
}


