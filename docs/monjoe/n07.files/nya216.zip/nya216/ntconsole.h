#ifndef NTCONSOLE_H
#define NTCONSOLE_H

class NnString;
class Console {
public:
    static void backspace(int n=1);
#if 0 /* def NYACUS */
    static void keep_bottom_line();
#endif
    static void clear();
#ifdef NYACUS
    static void cursorOn();
#else
    static void cursorOn(){}
#endif
    static int getkey();
    static void writeClipBoard( const char *s , int len );
    static void readClipBoard( NnString &buffer );
};

#endif
