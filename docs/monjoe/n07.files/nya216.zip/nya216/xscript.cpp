#include "config.h"
#include "ntconsole.h"

#ifdef NYACUS

#include "getline.h"
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <windows.h>

/* UK-taniyama���̃R�[�h�ɑ΂��A���̕ύX���s���܂����i�͂�܁j
 *
 * �E�N���X�̒��ŃC�����C��������Ă��������o�֐����A
 *   �N���X�錾�̊O�Œ�`������悤�ɂ����B
 *   (while ��� if �Ōx�����o��̂�)
 * �E�N���b�v�{�[�h�A�N�Z�X�� ntconsole.cpp �̊֐���p����悤�ɂ����B
 * �E�^�u���W�^�u�ɕύX�����B
 * �ECtrl-F/B/N/P �ȂǂŃJ�[�\�����ړ��ł���悤�ɂ����B
 *
 */
class XScript {
private:
    bool isSelecting;
    COORD cursor;
    COORD start;
    COORD end;
    HANDLE hConsoleOutput;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
public:
    XScript();
    void loop();
    void setCursor( const COORD& cursor)
	{ ::SetConsoleCursorPosition( hConsoleOutput, cursor); }
    void invartRect();
    void invartPoint( const COORD& cursor);
    void expandTo( const COORD& cursor);
    void copyToClipboard();
};

#define CTRL(x) ((x)&0x1F)


XScript::XScript()
{
    hConsoleOutput = ::GetStdHandle( STD_OUTPUT_HANDLE);
    ::GetConsoleScreenBufferInfo( hConsoleOutput, &csbi);
    cursor = csbi.dwCursorPosition;
}

void XScript::invartPoint( const COORD& cursor)
{
    WORD attr;
    DWORD size;
    ::ReadConsoleOutputAttribute( hConsoleOutput, &attr, 1, cursor, &size);
    attr = ((attr&0xF)<<4)|(attr>>4);
    ::WriteConsoleOutputAttribute( hConsoleOutput, &attr, 1, cursor, &size);
}

void XScript::loop()
{
    char title[1024];
    GetConsoleTitle( title, sizeof title);
    isSelecting = false;
    SetConsoleTitle( "XScript");
    while( 1){
	int ch = getch();
	if( ch==0x0D || ch==0x1B ){
	    if( isSelecting){
		if( ch==0x0D ){
		    copyToClipboard();
		}
		invartRect();
	    }
	    setCursor( csbi.dwCursorPosition);
	    break;
	}

	if( !isSelecting){
	    start = end = cursor;
	}

	//�J�[�\���̈ړ�
	bool moveCursor = true;
	switch( ch){
	case 0x77:	/* ^Home */
        case '<':
	    cursor.X = cursor.Y = 0;
	    break;

	case 0x47:	/* Home */
        case '0':
        case '^':
        case CTRL('a'):
	    cursor.X = 0;
	    break;
	case 0x4F:	/* End */
        case '$':
        case CTRL('e'):
	    cursor.X = csbi.dwSize.X-1;
	    break;
	case 0x75:	/* ^End */
        case '>':
	    cursor.X = csbi.dwSize.X-1;
	    cursor.Y = csbi.dwCursorPosition.Y;
	    break;
	case 0x48:	/* �� */
	case 0x8D:	/* ^�� */
        case CTRL('p'):
	    cursor.Y--;
	    break;
	case 0x49:	/* PgUp */
	case 0x86:	/* ^PgUp */
        case CTRL('z'):
	    cursor.Y -= csbi.srWindow.Bottom-csbi.srWindow.Top;
	    break;
	case 0x51:	/* PgDn */
	case 0x76:	/* ^PgDn */
        case CTRL('v'):
	    cursor.Y += csbi.srWindow.Bottom-csbi.srWindow.Top;
	    break;
	case 0x4B:	/* �� */
	case 0x73:	/* �� */
        case CTRL('b'):
	    cursor.X--;
	    break;
	case 0x50:	/* �� */
	case 0x91:	/* ^�� */
        case CTRL('n'):
	    cursor.Y++;
	    break;
	case 0x4D:	/* �� */
	case 0x74:	/* �� */
        case CTRL('f'):
	    cursor.X++;
	    break;
	default:
	    moveCursor = false;
	    break;
	}

	if( !moveCursor){
	    continue;
	}
	if( cursor.Y>csbi.dwCursorPosition.Y){
	    cursor.Y = csbi.dwCursorPosition.Y;
	}else if( cursor.Y<0){
	    cursor.Y = 0;
	}
	setCursor( cursor);

	//�J�[�\���̎擾
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo( hConsoleOutput, &csbi);
	cursor = csbi.dwCursorPosition;

	//�I������
	if( GetKeyState( VK_SHIFT)&0x8000){		//�I���J�n
	    if( !isSelecting){
		SetConsoleTitle( "XScript[�I�𒆁c]");
		isSelecting = true;
		end = cursor;
		invartRect();
	    }else{
		expandTo( cursor);
	    }
	}else{ //��I��
	    if( isSelecting){
		SetConsoleTitle( "XScript");
		isSelecting = false;
		invartRect();
	    }
	}
    }
    SetConsoleTitle( title );
}

void XScript::invartRect()
{
    int x0, x1, y0, y1;
    if( start.X<end.X){
	x0 = start.X;	x1 = end.X;
    }else if( start.X==end.X){
	x0 = start.X;	x1 = start.X;
    }else{
	x0 = end.X;		x1 = start.X;
    }
    if( start.Y<end.Y){
	y0 = start.Y;	y1 = end.Y;
    }else if( start.Y==end.Y){
	y0 = start.Y;	y1 = start.Y;
    }else{
	y0 = end.Y;		y1 = start.Y;
    }
    COORD cursor;
    for( cursor.X=x0; cursor.X<=x1; ++cursor.X){
	for( cursor.Y=y0; cursor.Y<=y1; ++cursor.Y){
	    invartPoint( cursor);
	}
    }
}

void XScript::expandTo( const COORD& cursor)
{
    if( end.X-cursor.X>1 || cursor.X-end.X>1 ||
	end.Y-cursor.Y>1 || cursor.Y-end.Y>1){
	invartRect();
	end = cursor;
	invartRect();
	return;
    }
    if( cursor.X!=end.X){
	int x0, x1, y0, y1;
	if( cursor.X<end.X){
	    if( cursor.X<start.X){
		x0 = cursor.X;	x1 = end.X;
	    }else{
		x0 = cursor.X+1;x1 = end.X+1;
	    }
	}else{
	    if( cursor.X<=start.X){
		x0 = end.X;		x1 = cursor.X;
	    }else if( cursor.X){
		x0 = end.X+1;	x1 = cursor.X+1;
	    }
	}
	if( start.Y<end.Y){
	    y0 = start.Y;	y1 = end.Y;
	}else if( start.Y==end.Y){
	    y0 = start.Y;	y1 = start.Y;
	}else{
	    y0 = end.Y;		y1 = start.Y;
	}
	COORD point;
	for( point.X=x0; point.X<x1; ++point.X){
	    for( point.Y=y0; point.Y<=y1; ++point.Y){
		invartPoint( point);
	    }
	}
	end.X = cursor.X;
    }
    if( cursor.Y!=end.Y){
	int x0, x1, y0, y1;
	if( cursor.Y<end.Y){
	    if( cursor.Y<start.Y){
		y0 = cursor.Y;	y1 = end.Y;
	    }else{
		y0 = cursor.Y+1;y1 = end.Y+1;
	    }
	}else{
	    if( cursor.Y<=start.Y){
		y0 = end.Y;		y1 = cursor.Y;
	    }else if( cursor.Y){
		y0 = end.Y+1;	y1 = cursor.Y+1;
	    }
	}
	if( start.X<end.X){
	    x0 = start.X;	x1 = end.X+1;
	}else if( start.X==end.X){
	    x0 = start.X;	x1 = start.X+1;
	}else{
	    x0 = end.X;		x1 = start.X+1;
	}
	COORD point;
	for( point.X=x0; point.X<x1; ++point.X){
	    for( point.Y=y0; point.Y<y1; ++point.Y){
		invartPoint( point);
	    }
	}
	end.Y = cursor.Y;
    }
}

void XScript::copyToClipboard()
{
    int x0, x1, y0, y1;
    if( start.X<end.X){
	x0 = start.X;	x1 = end.X;
    }else if( start.X==end.X){
	x0 = start.X;	x1 = start.X;
    }else{
	x0 = end.X;		x1 = start.X;
    }
    if( start.Y<end.Y){
	y0 = start.Y;	y1 = end.Y;
    }else if( start.Y==end.Y){
	y0 = start.Y;	y1 = start.Y;
    }else{
	y0 = end.Y;		y1 = start.Y;
    }

    /* �]���p�̕�����𐶐�����B */
    NnString buffer;
    char line[10000];
    COORD cursor;
    cursor.X = 0;
    for( cursor.Y=y0; cursor.Y<=y1; ++cursor.Y){
	DWORD size;
	::ReadConsoleOutputCharacter( hConsoleOutput, line, sizeof line, cursor, &size);
	bool isKanji = false;
	int x;
	for( x=0; x<=x1; ++x){
	    if( isKanji){
		if( x==x0){
		    buffer += line[x-1];
		    buffer += line[x];
		}
		isKanji = false;
	    }else{
		if( IsDBCSLeadByte( line[x])){
		    isKanji = true;
		    if( x>=x0){
			buffer += line[x];
			buffer += line[x+1];
		    }
		}else{
		    if( x>=x0){
			buffer += line[x]? line[x]: ' ';
		    }
		}
	    }
	}
	buffer += '\r';
	buffer += '\n';
    }

    /* �N���b�v�{�[�h�ɓ]�� */
    Console::writeClipBoard( buffer.chars() , buffer.length() );

//     if( !::OpenClipboard( 0)){
// 	return;
//     }
//     HANDLE hcfText = ::GlobalAlloc(GMEM_DDESHARE, buffer.length()+1);
//     if( hcfText){
// 	char* ptr = (char*)::GlobalLock( hcfText);
// 	if( ptr){
// 	    memcpy( ptr, buffer.chars(), buffer.length()+1);
// 	    ::EmptyClipboard();
// 	    ::GlobalUnlock( hcfText);
// 	    ::SetClipboardData( CF_TEXT, hcfText);
// 	}
//     }
//     ::CloseClipboard();

}

Status GetLine::xscript(int)
{
    XScript xscript;
    xscript.loop();
    return CONTINUE;
}
#endif
/* vim:set sw=4 ts=8 et: */
