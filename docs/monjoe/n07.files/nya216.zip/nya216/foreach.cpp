#include <stdlib.h>
#include "nnstring.h"
#include "nnvector.h"
#include "nnstrhash.h"
#include "shell.h"

int fnexplode(const char *path , NnVector &list );

int BufferedShell::readline( NnString &line )
{
    if( count >= buffers.size() )
        return -1;
    line = *(NnString*)buffers.at(count++);
    return line.length();
}

extern NnStrHash properties;

/* foreach �ȂǁA����̃L�[���[�h�܂ł̕����� BufferedShell �֓ǂ݂���
 *  	shell  - ���͌��V�F��(�R�}���h���C���E�X�N���v�g�Ȃ�)
 *	bShell - �o�͐�V�F��
 *	prompt - �v�����v�g
 *	startKeyword - �u���b�N�J�n�L�[���[�h(�l�X�g�p)
 *	endKeyword - �u���b�N�I���L�[���[�h
 */
static void loadToBufferedShell( NyadosShell   &shell ,
				 BufferedShell &bShell ,
				 const char *prompt ,
				 const char *startKeyword ,
				 const char *endKeyword )
{
    NnString cmdline;
    int nest = 1;

    shell.nesting.append(new NnString(prompt));
    while( shell.readcommand(cmdline) >= 0 ){
        NnString arg1,left;
        cmdline.splitTo( arg1 , left );
        if( arg1.icompare(endKeyword)==0 && --nest <= 0 )
	    break;
        if( arg1.icompare(startKeyword)==0 )
            ++nest;
        bShell.append( (NnString*)cmdline.clone() );
        cmdline.erase();
    }
    delete shell.nesting.pop();
}

extern NnStrHash functions;
int cmd_sub( NyadosShell &shell , const NnString &argv )
{
    if( argv.empty() ){
	for( NnStrHash::Each e(functions) ; e.more() ; ++e ){
	    shell.out() << "sub " << e->key() << "\n";
	    BufferedShell *bShell=(BufferedShell*)e->value();
	    for(int i=0 ; i<bShell->size() ; ++i ){
		shell.out() << "\t" << bShell->statement(i) << "\n";
	    }
	    shell.out() << "endsub\n";
	}
	return 0;
    }
    BufferedShell *bShell=new BufferedShell();
    loadToBufferedShell( shell , *bShell , "sub>" , "sub" , "endsub" );

    functions.put( argv , bShell );
    return 0;
}


int cmd_foreach( NyadosShell &shell , const NnString &argv )
{
    /* �p�����[�^���� */
    NnString varname,rest;
    argv.splitTo(varname,rest);
    if( varname.empty() ){
        shell.err() << "foreach: foreach VARNAME VALUE-1 VALUE-2 ...\n";
        return 0;
    }
    varname.downcase();

    /* �o�b�t�@�� foreach �` end �܂ł̕���������߂� */
    BufferedShell bshell;
    loadToBufferedShell( shell , bshell , "foreach>" , "foreach" , "end" );

    NnString *orgstr=(NnString*)properties.get( varname );
    NnString *savevar=(NnString*)( orgstr != NULL ? orgstr->clone() : NULL );

    /* �����W�J */
    NnVector list;
    for(;;){
        NnString arg1;

        rest.splitTo( arg1 , rest );
        if( arg1.empty() )
            break;
        
        /* ���C���h�J�[�h�W�J */
        NnVector sublist;
        if( fnexplode( arg1.chars() , sublist ) != 0 )
            goto memerror;
        
        if( sublist.size() <= 0 ){
            if( list.append( arg1.clone() ) )
                goto memerror;
        }else{
            while( sublist.size() > 0 ){
                if( list.append(sublist.shift()) != 0 )
                    goto memerror;
            }
        }
    }
    {
	NnVector *param=new NnVector();
	if( param == NULL )
	    goto memerror;
	for(int j=0 ; j<shell.argc() ; ++j )
	    param->append( shell.argv(j)->clone() );
	bshell.setArgv(param);
    }

    /* �R�}���h���s */
    for(int i=0 ; i<list.size() ; i++){
        properties.put( varname , list.at(i)->clone() );
        bshell.mainloop();
        bshell.rewind();
    }
    properties.put_( varname , savevar );
    return 0;

  memerror:
    shell.err() << "foreach: memory allocation error\n";
    return 0;
}
