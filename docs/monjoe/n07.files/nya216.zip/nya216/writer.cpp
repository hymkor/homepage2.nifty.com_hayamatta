#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <io.h>
#include "nndir.h"
#include "writer.h"
#include "reader.h"

StreamWriter conOut(stdout),conErr(stderr);

Writer::~Writer(){}

Writer &Writer::operator << (int n)
{
    NnString tmp;
    tmp.addValueOf( n );
    return *this << tmp.chars();
#if 0
    if( n < 0 ){
        *this << '-';
        return *this << -n;
    }
    if( n >= 10 ){
        *this << (n/10) ;
        n %= 10;
    }
    return *this << "0123456789"[n];
#endif
}

Writer &Writer::write( const char *s )
{
    while( *s != '\0' )
        *this << *s++;
    return *this;
}

Writer &StreamWriter::write( char c )
{
    fputc( c , fp_ );
    return *this;
}
Writer &StreamWriter::write( const char *s )
{
    fputs( s , fp_ );
    return *this;
}

void PipeWriter::open( const NnString &cmds_ )
{
#ifdef NYADOS
    tempfn = NnDir::tempfn();
    FILE *fp = fopen( tempfn.chars() , "w" );
#elif defined(__BORLANDC__)
    FILE *fp = _popen( cmds_.chars() , "w" );
#else
    FILE *fp = popen( cmds_.chars() , "w" );
#endif
    if( fp == NULL )
        return;
    cmds   = cmds_;
    cmds.trim();
    setFp( fp );
}

PipeWriter::PipeWriter( const char *s )
{
    NnString cmds_(s);
    open( cmds_ );
}

PipeWriter::~PipeWriter()
{
    if( fp() == NULL )
        return;
    
#ifdef NYADOS
    fclose( fp() );

#if 1
    {
	Redirect redirect0(0);
	redirect0.switchTo( tempfn.chars() ,"r" );
	system( cmds.chars() );
    }
#else
    int quote=0;
    const char *p=cmds.chars();
    for(;;){
        if( *p == '"' )
            quote = !quote;
        if( *p == '\0' ){
            if( quote )
                exestr << '"';
            exestr << " < " << tempfn;
            break;
        }
        if( quote == 0  &&  *p=='|' ){
            exestr << " < " << tempfn << ' ' << p;
            break;
        }
        exestr += *p++;
    }
    system( exestr.chars() );
#endif
    remove( tempfn.chars() );
#elif defined(__BORLANDC__)
    _pclose( fp() );
#else
    pclose( fp() );
#endif
}

#ifdef NYADOS

FileWriter::FileWriter( const char *fn , const char *mode )
{
    fd_=NnDir::open(fn,mode);
    size = 0;
}
FileWriter::FileWriter( const NnString &fn , const char *mode )
{
    fd_=NnDir::open(fn.chars() , mode );
    size = 0;
}

FileWriter::~FileWriter()
{
    if( fd_ != -1 ){
        if( size > 0 ){
            NnDir::write(fd_,buffer,size);
        }
        NnDir::close(fd_);
    }
}
void FileWriter::put( char c )
{
    buffer[ size++ ] = c;
    if( size >= sizeof(buffer) ){
        NnDir::write(fd_,buffer,size);
        size = 0;
    }
}
Writer &FileWriter::write( const char *s )
{
    while( *s != '\0' ){
        if( *s == '\n' )
            this->put('\r');
        this->put(*s++);
    }
    return *this;
}
Writer &FileWriter::write( char c )
{
    if( c == '\n' )
        this->put('\r');
    this->put('\n');
    return *this;
}
#else /* NYADOS �ȊO�̏ꍇ�́A�R���X�g���N�^�̂� */

FileWriter::FileWriter( const char *fn , const char *mode )
    : StreamWriter( fopen(fn,mode) )
{
    /* Borland C++ �ł́A�ŏ��ɏ������ނ܂ŁA�t�@�C���|�C���^��
     * �ړ����Ȃ��̂ŁAdup2 ���g���ꍇ�́A
     * �����I�� lseek �ňړ������Ă��K�v������B
     * (stdio �� io �����݂����Ďg���͖̂{���̓_���Ȃ̂ŁA����͌����Ȃ��c)
     */
    if( *mode == 'a' )
	fseek( fp() , 0 , SEEK_END );
}


FileWriter::~FileWriter()
{
    if( ok() )
        fclose( this->fp() );
}

#endif

/* �W���o�́E���͂����_�C���N�g����
 *      x - �t�@�C���n���h��
 */
void Redirect::set(int x)
{
    if( original_fd == -1 )
        original_fd = dup(fd());
    dup2( x , fd() );
    isOpenFlag = 1;
}

void Redirect::close()
{
    if( original_fd != -1  &&  isOpenFlag ){ 
        ::close( fd() );
        isOpenFlag = 0;
    }
}

/* ���_�C���N�g�����ɖ߂� */
void Redirect::reset()
{
    if( original_fd != -1 ){
        dup2( original_fd , fd() );
        ::close( original_fd );
        original_fd = -1;
    }
}

/* �t�@�C�������w�肵�āA���_�C���N�g����B
 *      fname - �t�@�C����
 *      mode  - ���[�h
 * return
 *      0 - ����
 *      -1 - ���s
 */
int Redirect::switchTo( const NnString &fname , const char *mode  )
{
    if( *mode == 'r' ){
	FileReader fr(fname.chars());
	if( fr.eof() )
	    goto errpt;
	this->set( fr.fd() );
    }else{
	FileWriter fw( fname.chars() , mode );
	if( ! fw.ok() )
	    goto errpt;
	this->set( fw.fd() );

    }
    return 0;
  errpt:
    conErr << fname << ": can't open temporary file.\n";
    return -1;
}

